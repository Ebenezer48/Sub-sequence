import java.util.*;

public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String n1 = sc.nextLine();
		String n2 = sc.nextLine();
		
		char[] arr1 = n1.toCharArray();
		char[] arr2 = n2.toCharArray();
		
		int i=0;
		int j=0;
		while(i<n1.length() && j<n2.length()){
		    if(arr1[i] == arr2[j]){
		        i++;
		        j++;
		    }else{
		        i++;
		        j = 0;
		    }
		}
		if(j == n2.length()){
		    System. out.println("Yes");
		}
		else{
		    System.out.println("No");
		}
	}
}
